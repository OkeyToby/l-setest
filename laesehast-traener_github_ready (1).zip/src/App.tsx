import ReadingSpeedTrainer from './ReadingSpeedTrainer'
export default function App(){return <ReadingSpeedTrainer/>}
